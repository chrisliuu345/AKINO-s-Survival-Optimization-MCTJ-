execute as @s run puffish_skills skills reset combat @s
execute as @s run puffish_skills skills reset marksmanship @s
execute as @s run puffish_skills skills reset survival @s
execute as @s run puffish_skills skills reset exploration @s
execute as @s run puffish_skills skills reset crafting @s
execute as @s run puffish_skills skills reset alchemy @s
